import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Aluno> alunos = lerArquivoAlunos("alunos.csv");

        if (alunos.isEmpty()) {
            System.out.println("Nenhum aluno encontrado no arquivo.");
            return;
        }

        // Processar os dados
        int quantidadeAlunos = alunos.size();
        int quantidadeAprovados = contarAprovados(alunos);
        int quantidadeReprovados = quantidadeAlunos - quantidadeAprovados;
        double menorNota = encontrarMenorNota(alunos);
        double maiorNota = encontrarMaiorNota(alunos);
        double mediaGeral = calcularMedia(alunos);

        // Gravar resultados no arquivo resumo.csv
        boolean sucesso = salvarResumo("resumo.csv", quantidadeAlunos, quantidadeAprovados,
                quantidadeReprovados, menorNota, maiorNota, mediaGeral);

        if (sucesso) {
            System.out.println("Resumo gravado com sucesso no arquivo resumo.csv.");
        } else {
            System.out.println("Erro ao gravar o resumo no arquivo resumo.csv.");
        }
    }

    // Método para ler o arquivo de alunos e criar a lista de objetos Aluno
    private static List<Aluno> lerArquivoAlunos(String nomeArquivo) {
        List<Aluno> alunos = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(nomeArquivo))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(";");
                if (dados.length >= 3) {
                    int matricula = Integer.parseInt(dados[0].trim());
                    String nome = dados[1].trim();
                    double nota = Double.parseDouble(dados[2].trim().replace(",", "."));
                    Aluno aluno = new Aluno(matricula, nome, nota);
                    alunos.add(aluno);
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo de alunos: " + e.getMessage());
        }

        return alunos;
    }

    // Método para contar a quantidade de alunos aprovados (nota >= 6.0)
    private static int contarAprovados(List<Aluno> alunos) {
        int count = 0;
        for (Aluno aluno : alunos) {
            if (aluno.getNota() >= 6.0) {
                count++;
            }
        }
        return count;
    }

    // Método para encontrar a menor nota entre os alunos
    private static double encontrarMenorNota(List<Aluno> alunos) {
        double menorNota = Double.MAX_VALUE;
        for (Aluno aluno : alunos) {
            if (aluno.getNota() < menorNota) {
                menorNota = aluno.getNota();
            }
        }
        return menorNota;
    }

    // Método para encontrar a maior nota entre os alunos
    private static double encontrarMaiorNota(List<Aluno> alunos) {
        double maiorNota = Double.MIN_VALUE;
        for (Aluno aluno : alunos) {
            if (aluno.getNota() > maiorNota) {
                maiorNota = aluno.getNota();
            }
        }
        return maiorNota;
    }

    // Método para calcular a média geral das notas dos alunos
    private static double calcularMedia(List<Aluno> alunos) {
        if (alunos.isEmpty()) {
            return 0.0;
        }

        double somaNotas = 0.0;
        for (Aluno aluno : alunos) {
            somaNotas += aluno.getNota();
        }
        return somaNotas / alunos.size();
    }

    // Método para salvar o resumo no arquivo resumo.csv
    private static boolean salvarResumo(String nomeArquivo, int quantidadeAlunos, int quantidadeAprovados,
            int quantidadeReprovados, double menorNota, double maiorNota, double mediaGeral) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(nomeArquivo))) {
            pw.println("Quantidade de alunos: " + quantidadeAlunos);
            pw.println("Quantidade de aprovados: " + quantidadeAprovados);
            pw.println("Quantidade de reprovados: " + quantidadeReprovados);
            pw.println("Menor nota: " + menorNota);
            pw.println("Maior nota: " + maiorNota);
            pw.println("Média geral: " + mediaGeral);
            return true;
        } catch (IOException e) {
            System.err.println("Erro ao salvar o resumo no arquivo: " + e.getMessage());
            return false;

        }
    }
}
